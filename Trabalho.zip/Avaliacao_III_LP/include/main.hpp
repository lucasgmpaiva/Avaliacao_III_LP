/**
* @author Lucas Gabriel Matias Paiva
* @file opPista.hpp
* @brief Cabe�alho do main - Todos os includes necess�rios
* @since 04/06/18
* @date 05/06/18
*/

#ifndef MAIN_HPP
#define MAIN_HPP
	#include "sapo.hpp"
	#include "corrida.hpp"
	#include "pista.hpp"
	#include "opPista.hpp"
	#include "funcArquivos.hpp"


#endif
